/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package taller33333;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.Timer;


/**
 *
 * @author jhons
 */
public class Carreras extends javax.swing.JFrame {
 List<TCarro> tiempos = new ArrayList<>();
    int c=0;
    int s1, s2, s3, s4, s5, s6, s7, s8, s9, s10;
    String Ganador= null;
    String carroA = "";
    boolean l1 = false;
    boolean l2 = false;
    boolean l3 = false;
    boolean l4 = false;
    boolean l5 = false;
    boolean l6 = false;
    boolean l7 = false;
    boolean l8 = false;
    boolean l9 = false;
    boolean l10 = false;
    ImageIcon im[]= new ImageIcon[10];
    Timer t1 = new Timer(1000, new ActionListener(){
        public void actionPerformed(ActionEvent e) {
        
        if(!l1) {    
        int a=(int)(Math.random()*50)+1;
        s1=s1+a; 
        c1.setLocation(s1,21);   
        stop();
         
          }
        c1.setIcon(im[0]);
            }});
    Timer t2 = new Timer(1000, new ActionListener(){
               
        public void actionPerformed(ActionEvent e) {
        if(!l2) { 
        int b=(int)(Math.random()*50)+1;
        s2=s2+b; 
        c2.setIcon(im[1]);
        c2.setLocation(s2,61);  
        
        stop();
        
        }
                
        } });
    Timer t3 = new Timer(1000, new ActionListener(){
                
        public void actionPerformed(ActionEvent e) {
        c3.setIcon(im[2]);
        if(!l3) { 
        int c=(int)(Math.random()*50)+1;
        s3=s3+c; 
        c3.setLocation(s3,101); 
        stop();

   
    }
        } });
    Timer t4 = new Timer(1000, new ActionListener(){
               
        public void actionPerformed(ActionEvent e) {
        if(!l4) { 
        int d=(int)(Math.random()*50)+1;
        s4=s4+d; 
        c4.setLocation(s4,141);
        c4.setIcon(im[3]);
        stop();

        }           
        }   });
    
    Timer t5 = new Timer(1000, new ActionListener(){
               
        public void actionPerformed(ActionEvent e) {
        if(!l5) { 
        int f =(int)(Math.random()*50)+1;
        s5=s5+f; 
        c5.setLocation(s5,181); 
        c5.setIcon(im[4]);
        stop();

        }      
        }   });
    
    Timer t6 = new Timer(1000, new ActionListener(){
               
        public void actionPerformed(ActionEvent e) {
        if(!l6) { 
        int g =(int)(Math.random()*50)+1;
        s6=s6+g; 
        c6.setLocation(s6,215); 
        c6.setIcon(im[5]);
        stop();

        }        
        }   });
    
    Timer t7 = new Timer(1000, new ActionListener(){
               
        public void actionPerformed(ActionEvent e) {
        if(!l7) { 
        int h =(int)(Math.random()*50)+1;
        s7=s7+h; 
        c7.setLocation(s7,246); 
        c7.setIcon(im[6]);
        stop();

        }       
        }  });
   
    Timer t8 = new Timer(1000, new ActionListener(){
               
        public void actionPerformed(ActionEvent e) {
        if(!l8) { 
        int i =(int)(Math.random()*50)+1;
        s8=s8+i; 
        c8.setLocation(s8,280);
        c8.setIcon(im[7]);
        stop();
        }       
        }   });
    
    Timer t9 = new Timer(1000, new ActionListener(){
               
        public void actionPerformed(ActionEvent e) {
        if(!l9) { 
        int j=(int)(Math.random()*50)+1;
        s9=s9+j; 
        c9.setLocation(s9,320);
        c9.setIcon(im[8]);
        stop();

        }        
        }   });
    
    Timer t10 = new Timer(1000, new ActionListener(){
               
        public void actionPerformed(ActionEvent e) {
        if(!l10) {
        int k=(int)(Math.random()*50)+1;
        s10=s10+k; 
        c10.setLocation(s10,360);
        
        stop();
         c10.setIcon(im[9]);
        }
       
        }   });
    
    public Carreras() {
        initComponents();
        metodo();
    }
    public void metodo(){
        for(int i=1;i<=10;i++){
            ImageIcon imagen= new ImageIcon("im"+i+".jpeg");
            im[i-1]=imagen;
        }
    }
    long tI;
    void iniciarCarrera() {
    tI = System.currentTimeMillis(); 
    
    }
    void stop(){
    long tA = System.currentTimeMillis();
     if (!l1 && s1 >= jButton12.getX() + jButton12.getWidth()) {
       tiempos.add(new TCarro("carro1", tA));
       l1 = true;
        if (Ganador == null) {
            Ganador = "carro1";
         }
        t1.stop();
    }
    if (!l2 && s2 >= jButton12.getX() + jButton12.getWidth()) {
        tiempos.add(new TCarro("carro2", tA));
        l2 = true;
        if (Ganador == null) {
            Ganador = "carro2";
         }
        t2.stop();
    }
  if (!l3 && s3 >= jButton12.getX() + jButton12.getWidth()) {
        tiempos.add(new TCarro("carro3", tA));
        l3= true;       
        if (Ganador == null) {
            Ganador = "carro3";
         }
        t3.stop();
    }
   if (!l4 && s4 >= jButton12.getX() + jButton12.getWidth()) {
        tiempos.add(new TCarro("carro4", tA));
       l4 = true;
        if (Ganador == null) {
            Ganador= "carro4";
         }
        t4.stop();
    }
    if (!l5 && s5 >= jButton12.getX() + jButton12.getWidth()) {
        tiempos.add(new TCarro("carro5", tA));
        l5 = true;
        if (Ganador == null) {
            Ganador = "carro5";
         }
        t5.stop();
    }
     if (!l6 && s6 >= jButton12.getX() + jButton12.getWidth()) {
        tiempos.add(new TCarro("carro6", tA));
         l6 = true;
            if (Ganador == null) {
            Ganador = "carro6";
         }
        t6.stop();
    }
      if (!l7 && s7 >= jButton12.getX() + jButton12.getWidth()) {
        tiempos.add(new TCarro("carro7", tA));
          l7 = true;
            if (Ganador == null) {
            Ganador = "carro7";
         }
        t7.stop();
    
    }
      if (!l8 && s8 >= jButton12.getX() + jButton12.getWidth()) {
          tiempos.add(new TCarro("carro8", tA));
          l8 = true;
       
             if (Ganador == null) {
            Ganador= "carro8";
         }
        t8.stop();
    }
       if (!l9 && s9 >= jButton12.getX() + jButton12.getWidth()) {
        tiempos.add(new TCarro("carro9", tA));
           l9 = true;
            if (Ganador == null) {
            Ganador= "carro9";
         }
        t9.stop();
    }
        if (!l10 && s10 >= jButton12.getX() + jButton12.getWidth()) {
        tiempos.add(new TCarro("carro10", tA));
            l10 = true;
      
             if (Ganador == null) {
            Ganador = "carro10";
         }
        t10.stop();
    }
}
    
    public class TCarro implements Comparable<TCarro> {
    private String nCarro;
    private long tLlegada;

    public TCarro(String nCarro, long tLlegada) {
        this.nCarro = nCarro;
        this.tLlegada = tLlegada;
    }

    public String getNCarro() {
        return nCarro;
    }

    public long getTLlegada() {
        return tLlegada;
    }
     @Override
    public int compareTo(TCarro CarroX) {
        return Long.compare(this.tLlegada, CarroX.tLlegada);
    }
}
    void mostrarT() {
    Collections.sort(tiempos); 

    jTextArea1.setText("TIEMPOS DE CADA CARRO:\n");

    for (TCarro tCarro : tiempos) {
        long tiempoT = tCarro.getTLlegada() - tI; 
        jTextArea1.append(tCarro.getNCarro() + ": " + tiempoT+ " milisegundos\n");
    }
}
    private void reiniciar() {
    
    s1 = s2 = s3 = s4 = s5 = s6 = s7 = s8 = s9 = s10 = 0;
    l1 = l2 = l3 = l4 = l5 = false;
    l6 = l7 = l8 = l9 = l10 = false;
    Ganador= null;
    tiempos.clear(); 
    iniciarCarrera(); 
}
    private void limpiar() {
    tiempos.clear(); 
    mostrarT(); 
}
    /**
     * Creates new form Carreras
     */

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        c1 = new javax.swing.JButton();
        c2 = new javax.swing.JButton();
        c3 = new javax.swing.JButton();
        c4 = new javax.swing.JButton();
        c5 = new javax.swing.JButton();
        c6 = new javax.swing.JButton();
        c7 = new javax.swing.JButton();
        c8 = new javax.swing.JButton();
        c9 = new javax.swing.JButton();
        c10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        Slider = new javax.swing.JSlider();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        c1.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Imágenes\\BUgatti2.png")); // NOI18N

        c2.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Imágenes\\Carro1.jpeg")); // NOI18N
        c2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c2ActionPerformed(evt);
            }
        });

        c3.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Escritorio\\huracan.jpg")); // NOI18N
        c3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c3ActionPerformed(evt);
            }
        });

        c4.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Escritorio\\lamboblanco.png")); // NOI18N

        c5.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Escritorio\\Lambo.png")); // NOI18N

        c6.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Escritorio\\ll.jpg")); // NOI18N
        c6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c6ActionPerformed(evt);
            }
        });

        c7.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Escritorio\\mustang.png")); // NOI18N
        c7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c7ActionPerformed(evt);
            }
        });

        c8.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Escritorio\\n.png")); // NOI18N

        c9.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Escritorio\\ferrari.png")); // NOI18N

        c10.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Escritorio\\Conv.png")); // NOI18N

        jButton11.setText("Reiniciar");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton13.setText("Resultado");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.setText("Tiempos");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.setText("Iniciar");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        Slider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                SliderStateChanged(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Carro1", "Carro2", "Carro3", "Carro4", "Carro5", "Carro6", "Carro7", "Carro8", "Carro9", "Carro10" }));

        jLabel1.setText("Ingrese el carro que crea que va a ganar");

        jLabel2.setText("Velocidad");

        jButton1.setIcon(new javax.swing.ImageIcon("C:\\Users\\jhons\\OneDrive\\Imágenes\\Carros\\carretera.jpg")); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Slider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel2)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 121, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jButton15)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jButton14)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jButton13)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jButton11)))
                                .addGap(57, 57, 57))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(c10)
                            .addComponent(c9)
                            .addComponent(c8)
                            .addComponent(c7)
                            .addComponent(c6)
                            .addComponent(c5)
                            .addComponent(c4)
                            .addComponent(c3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(c2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(c1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 492, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(c1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(c10))
                    .addComponent(jButton12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton11)
                        .addComponent(jButton13)
                        .addComponent(jButton14)
                        .addComponent(jButton15))
                    .addComponent(Slider, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
    iniciarCarrera();
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        t6.start();
        t7.start();
        t8.start();
        t9.start();
        t10.start();
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
   reiniciar();
       limpiar();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
       mostrarT(); 
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
jTextArea2.setText("El carro ganador fue el carro" + Ganador);
    
    }//GEN-LAST:event_jButton13ActionPerformed

    private void SliderStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_SliderStateChanged
  int v=Slider.getValue();
  
        t1.setDelay(1000 / v);
        t2.setDelay(1000 / v);
        t3.setDelay(1000 / v);
        t4.setDelay(1000 / v);
        t5.setDelay(1000 / v);
        t6.setDelay(1000 / v);
        t7.setDelay(1000 / v);
        t8.setDelay(1000 / v);
        t9.setDelay(1000 / v);
        t10.setDelay(1000 / v);
    }//GEN-LAST:event_SliderStateChanged

    private void c2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_c2ActionPerformed

    private void c3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_c3ActionPerformed

    private void c6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_c6ActionPerformed

    private void c7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_c7ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Carreras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Carreras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Carreras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Carreras.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Carreras().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSlider Slider;
    private javax.swing.JButton c1;
    private javax.swing.JButton c10;
    private javax.swing.JButton c2;
    private javax.swing.JButton c3;
    private javax.swing.JButton c4;
    private javax.swing.JButton c5;
    private javax.swing.JButton c6;
    private javax.swing.JButton c7;
    private javax.swing.JButton c8;
    private javax.swing.JButton c9;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    // End of variables declaration//GEN-END:variables
}

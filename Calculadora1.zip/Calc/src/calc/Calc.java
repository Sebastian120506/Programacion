package Calc;

public class Calc {

      public double num1, num2, resultado, Resultado, Sen, Tang, Raiz, porc, iv, total, Iva, R, trig, totaliva; 
    
    public void suma(){
        resultado = num1 + num2; 
    }
    
    public void resta(){
        resultado = num1-num2;
    }
    
    public void multi(){
        resultado = num1 * num2;  
    }
      public void divi(){
         resultado = num1 / num2;   
    }
    
    public void cos(double a){
        Resultado=(float)Math.cos(a);
    }
    
    public void sen(double a){
        Sen=(float)Math.sin(a);
}
    public void tan(double a){
        Tang=(float)Math.tan(a);
}
    public void raiz(double a){
        R =(float)Math.sqrt(a);
}
        public void pote(){
        resultado = Math.pow(num1, num2);
}
   
    public void iva(){
        porc = num2 * 0.01;
        iv = num1 * porc;
        resultado = num1 + iv;
}

}




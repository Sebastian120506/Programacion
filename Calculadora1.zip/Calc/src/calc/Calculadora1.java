package Calc;

import java.util.Scanner;

public class Calculadora1 {

    public static void main(String[] args) {
        
        int menu;
        menu = 0;
        Scanner ingreso = new Scanner(System.in);
        Calc cal = new Calc();

        System.out.println("Bienveniddo a la calculadora");
        System.out.println("Seleccion la opcion que quiere realizar");
        System.out.println("Opcion 1.Suma ");
        System.out.println("Opcion 2.Resta ");
        System.out.println("Opcion 3.Multiplicacion ");
        System.out.println("Opcion 4.Division ");
        System.out.println("Opcion 5.Coseno ");
        System.out.println("Opcion 6.Seno ");
        System.out.println("Opcion 7.Tangente ");
        System.out.println("Opcion 8.Potencia ");
        System.out.println("Opcion 9.Raiz ");
        System.out.println("Opcion 10.Iva ");
        
        
        menu = ingreso.nextInt();
        System.out.println("Ingrese el numero 1");
        float a = ingreso.nextFloat();
        System.out.println("Ingrese el numero 2");
        float b = ingreso.nextFloat();
        cal.num1 = a;
        cal.num2 = b;
        switch (menu){
            case 1:
                System.out.println("Usted a seleccionado la operacion suma");
                System.out.println("Ingrese el numero 2");
                cal.suma();
                System.out.println("El resultado de la suma es: "+cal.resultado);
                break;
            case 2:
                System.out.println("Usted a seleccionado la operacion resta");
                cal.resta();
                System.out.println("El resultado de la resta es: "+cal.resultado);
                break;
            case 3: 
                System.out.println("Usted a seleccionado la operacion multiplicacion");
                cal.multi();
                System.out.println("El resultado de la multiplicacion es: "+cal.resultado);
                break;
            case 4:
                System.out.println("Usted a seleccionado la operacion division");
                cal.divi();
                if(b == 0){
                } else {
                  System.out.println("El resultado de la division es: "+cal.resultado);
                }
                 break;  
            case 5:
                System.out.println("Usted a seleccionado la operacion coseno");
                cal.cos(a);
                System.out.println("El resultado del coseno es: "+cal.Resultado);
                break;
            case 6:
                System.out.println("Usted a seleccionado la operacion seno");
                cal.sen(a);
                System.out.println("El resultado del seno es: "+cal.Sen);
                break;
            case 7:
                System.out.println("Usted a seleccionado la operacion tangente");
                cal.tan(a);
                System.out.println("El resultado de la tangente es: "+cal.Tang);
                break;
            case 8:
                System.out.println("Usted a seleccionado la operacion potencia");
                cal.pote();
                System.out.println("El resultado de la portencia es: "+cal.resultado);
                break;
            case 9:
                System.out.println("Usted a seleccionado la operacion raiz");
                cal.raiz(a);
                System.out.println("El resultado de la raiz es: "+cal.R);
                break;
            case 10:
                System.out.println("Usted a seleccionado la operacion Iva");
                System.out.println("Recuerde primer digito en pesos, segundo digito en %");
                cal.iva();
                System.out.println("El valor del producto mas IVA es  " + cal.resultado);
                System.out.println("El valor del IVA es  " + cal.iv);
        }
        System.out.println("Final de calculo");
        
        
       
        
        

        

      
        
        /*cal.cos(a);
        System.out.println("El resultado del coseno es: "+cal.Resultado);
        
        cal.sin(a);
        System.out.println("El resultado del seno es: "+cal.Sen);
        
        cal.tan(a);
        System.out.println("El resultado de la tangente es: "+cal.Tang);*/
    }
}

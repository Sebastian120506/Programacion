package calculadora;

public class Calculadora{

        
    public float num1, num2, resultado; 
    
    public void suma(){
        resultado = num1 + num2; 
    }
    
    public float resta(){
        return num1-num2;
    }
    public void cos(double a){
        resultado=(float)(Math.cos(a));
    }
}

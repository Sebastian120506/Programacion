package calculadora;

import java.util.Scanner;


public class Taller{

    public static void main(String[] args) {
        
        Scanner ingreso = new Scanner(System.in);
        Calculadora calcu1 = new Calculadora(); 
        
        
        
        System.out.println("Ingrese el numero 1"); 
        float a=ingreso.nextFloat(); 
        System.out.println("Ingrese el numero 2"); 
        float b=ingreso.nextFloat(); 
        
        calcu1.num1=a;
        calcu1.num2=b;
        calcu1.suma();
        
        
        System.out.println("El resultado de la suma es: " +calcu1.resultado);
        
        calcu1.num1=a;
        calcu1.num2=b;
                
        float r =calcu1.resta();
        System.out.println("El resultado de la resta es: " +r);
        
           }
    
    
}

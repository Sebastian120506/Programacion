
package guiapkg22;

import java.util.Scanner;


public class Arreglos {

    
    public void ejecutar() {
      
      Scanner teclado = new Scanner(System.in);
      int eleccion;
      int tamano;
      Ordenamiento Punto2=new Ordenamiento();
      do{
      System.out.println("Bienvenido al metodo de ordenamiento");
      System.out.println("Ingrese el metodo de ordenamiento que prefiera");
      System.out.println("1.100");
      System.out.println("2.500");
      System.out.println("3.1000");
      System.out.println("4.5000");
      System.out.println("5.10000");
      System.out.println("6.salir");
      eleccion = teclado.nextInt();
      switch (eleccion) {
            case 1 -> {
                tamano = 100;
                double[] arreglo100 = Ordenamiento.generarArregloAleatorio(tamano);
                long tiempoInicio100, tiempoFin100;
                tiempoInicio100 = System.nanoTime();
                Punto2.burbuja(tamano, arreglo100);
                tiempoFin100 = System.nanoTime();
                System.out.println("Tiempo de burbuja para 100 elementos: "+ (tiempoFin100 - tiempoInicio100) + " nanosegundos");
                tiempoInicio100 = System.nanoTime();
                Punto2.insercion(arreglo100);
                tiempoFin100 = System.nanoTime();
                System.out.println("Tiempo de insercion para 100 elementos: " + (tiempoFin100 - tiempoInicio100) + " nanosegundos");
                tiempoInicio100 = System.nanoTime();
                Punto2.seleccion(arreglo100);
                tiempoFin100 = System.nanoTime();
                System.out.println("Tiempo de seleccion para 100 elementos: "+ (tiempoFin100 - tiempoInicio100) + " nanosegundos");
                tiempoInicio100 = System.nanoTime();
                Ordenamiento.mergesort(arreglo100, 0, arreglo100.length - 1);
                tiempoFin100 = System.nanoTime();
                System.out.println("Tiempo de mergesort para 100 elementos: "+ (tiempoFin100 - tiempoInicio100) + " nanosegundos");
              }
            case 2 -> {
                tamano = 500;
                double[] arreglo500 = Ordenamiento.generarArregloAleatorio(tamano);
                long tiempoInicio500, tiempoFin500;
                tiempoInicio500 = System.nanoTime();
                Punto2.burbuja(tamano, arreglo500);
                tiempoFin500 = System.nanoTime();
                System.out.println("Tiempo de burbuja para 500 elementos: "+ (tiempoFin500 - tiempoInicio500) + " nanosegundos");
                tiempoInicio500 = System.nanoTime();
                Punto2.insercion(arreglo500);
                tiempoFin500 = System.nanoTime();
                System.out.println("Tiempo de insercion para 500 elementos: " + (tiempoFin500 - tiempoInicio500) + " nanosegundos");
                tiempoInicio500 = System.nanoTime();
                Punto2.seleccion(arreglo500);
                tiempoFin500 = System.nanoTime();
                System.out.println("Tiempo de seleccion para 500 elementos: "+ (tiempoFin500 - tiempoInicio500) + " nanosegundos");
                tiempoInicio500 = System.nanoTime();
                Ordenamiento.mergesort(arreglo500, 0, arreglo500.length - 1);
                tiempoFin500 = System.nanoTime();
                System.out.println("Tiempo de mergesort para 500 elementos: "+ (tiempoFin500 - tiempoInicio500) + " nanosegundos");
              }
            case 3 -> {
                tamano = 1000;
                double[] arreglo1000 = Ordenamiento.generarArregloAleatorio(tamano);
                long tiempoInicio1000, tiempoFin1000;
                tiempoInicio1000 = System.nanoTime();
                Punto2.burbuja(tamano, arreglo1000);
                tiempoFin1000 = System.nanoTime();
                System.out.println("Tiempo de burbuja para 1000 elementos: "+ (tiempoFin1000 - tiempoInicio1000) + " nanosegundos");
                tiempoInicio1000 = System.nanoTime();
                Punto2.insercion(arreglo1000);
                tiempoFin1000 = System.nanoTime();
                System.out.println("Tiempo de insercion para 1000 elementos: " + (tiempoFin1000 - tiempoInicio1000) + " nanosegundos");
                tiempoInicio1000 = System.nanoTime();
                Punto2.seleccion(arreglo1000);
                tiempoFin1000 = System.nanoTime();
                System.out.println("Tiempo de seleccion para 1000 elementos: "+ (tiempoFin1000 - tiempoInicio1000) + " nanosegundos");
                tiempoInicio1000 = System.nanoTime();
                Ordenamiento.mergesort(arreglo1000, 0, arreglo1000.length - 1);
                tiempoFin1000 = System.nanoTime();
                System.out.println("Tiempo de mergesort para 1000 elementos: "+ (tiempoFin1000 - tiempoInicio1000) + " nanosegundos");
              }
            case 4 -> {
                tamano = 5000;
                double[] arreglo5000 = Ordenamiento.generarArregloAleatorio(tamano);
                long tiempoInicio5000, tiempoFin5000;
                tiempoInicio5000 = System.nanoTime();
                Punto2.burbuja(tamano, arreglo5000);
                tiempoFin5000 = System.nanoTime();
                System.out.println("Tiempo de burbuja para 5000 elementos: "+ (tiempoFin5000 - tiempoInicio5000) + " nanosegundos");
                tiempoInicio5000 = System.nanoTime();
                Punto2.insercion(arreglo5000);
                tiempoFin5000 = System.nanoTime();
                System.out.println("Tiempo de insercion para 5000 elementos: " + (tiempoFin5000 - tiempoInicio5000) + " nanosegundos");
                tiempoInicio5000 = System.nanoTime();
                Punto2.seleccion(arreglo5000);
                tiempoFin5000 = System.nanoTime();
                System.out.println("Tiempo de seleccion para 5000 elementos: "+ (tiempoFin5000 - tiempoInicio5000) + " nanosegundos");
                tiempoInicio5000 = System.nanoTime();
                Ordenamiento.mergesort(arreglo5000, 0, arreglo5000.length - 1);
                tiempoFin5000 = System.nanoTime();
                System.out.println("Tiempo de mergesort para 5000 elementos: "+ (tiempoFin5000 - tiempoInicio5000) + " nanosegundos");
              }
            case 5 -> {
                tamano = 10000;
                double[] arreglo10000 = Ordenamiento.generarArregloAleatorio(tamano);
                long tiempoInicio10000, tiempoFin10000;
                tiempoInicio10000 = System.nanoTime();
                Punto2.burbuja(tamano, arreglo10000);
                tiempoFin10000 = System.nanoTime();
                System.out.println("Tiempo de burbuja para 10000 elementos: "+ (tiempoFin10000 - tiempoInicio10000) + " nanosegundos");
                tiempoInicio10000 = System.nanoTime();
                Punto2.insercion(arreglo10000);
                tiempoFin10000 = System.nanoTime();
                System.out.println("Tiempo de insercion para 10000 elementos: " + (tiempoFin10000 - tiempoInicio10000) + " nanosegundos");
                tiempoInicio10000 = System.nanoTime();
                Punto2.seleccion(arreglo10000);
                tiempoFin10000 = System.nanoTime();
                System.out.println("Tiempo de seleccion para 10000 elementos: "+ (tiempoFin10000 - tiempoInicio10000) + " nanosegundos");
                tiempoInicio10000 = System.nanoTime();
                Ordenamiento.mergesort(arreglo10000, 0, arreglo10000.length - 1);
                tiempoFin10000 = System.nanoTime();
                System.out.println("Tiempo de mergesort para 10000 elementos: "+ (tiempoFin10000 - tiempoInicio10000) + " nanosegundos");
              }
            case 6 -> eleccion=6;
                        }
                        
    }while (eleccion != 6);

    
}   
}

package guiapkg22;

import java.util.Scanner;


public class Calculadora {
   public void ejecutar() {
    
      Scanner teclado = new Scanner(System.in);
      int s;
      int a,b;
    do{
      Matrices punto1=new  Matrices ();
      System.out.println("Usted ha ingresado a la calculadora de matrices");
      System.out.println("Ingrese una opcion:");
      System.out.println("1. Suma");
      System.out.println("2. producto");
      System.out.println("3. producto de un escalar ");
      System.out.println("4. Transpuesta");
      System.out.println("5. salir");
      s= teclado.nextInt();
      switch(s){
        case 1 -> {
            System.out.print("Ingrese las filas para la matriz 1");
            a= teclado.nextInt();
            System.out.print("Ingrese las columnas para la matriz 1");
            b= teclado.nextInt();
            punto1.matrizA = new int[a][b];
            punto1.completarMatriz(punto1.matrizA, teclado);
            System.out.print("Ingrese las filas para la matriz 2 ");
            a= teclado.nextInt();
            System.out.print("Ingrese las columnas para la matriz 2 ");
            b= teclado.nextInt();
            punto1.matrizB = new int[a][b]; 
            punto1.completarMatriz(punto1.matrizB, teclado);
            punto1.suma();
            System.out.println("La suma es: ");
            for (int i = 0; i < punto1.matrizR.length; i++) {
                for (int j = 0; j < punto1.matrizR[0].length; j++) {
                    System.out.print(punto1.matrizR[i][j] + " ");
                }
                System.out.println();
            }
            }
             case 2 -> {
                 System.out.print("Ingrese las filas para la matriz 1");
                 a= teclado.nextInt();
                 System.out.print("Ingrese las columnas para la matriz 1 ");
                 b= teclado.nextInt();
                 punto1.matrizA= new int[a][b];
                 punto1.completarMatriz(punto1.matrizA, teclado);
                 System.out.print("Ingrese las filas para la matriz 2");
                 a= teclado.nextInt();
                 System.out.print("Ingrese las columnas para la matriz 2" );
                 b= teclado.nextInt();
                 punto1.matrizB = new int[a][b];
                 punto1.completarMatriz(punto1.matrizB,teclado);
                 punto1.producto();
                 System.out.println("El producto de las matrices es: ");
                 for (int i = 0; i < punto1.matrizR.length; i++) {
                     for (int j = 0; j < punto1.matrizR[0].length; j++) {
                         System.out.print(punto1.matrizR[i][j] + " ");
                     }
                     System.out.println();
                 }
            }
             case 3 -> {
                 System.out.print("Ingrese las filas para la matriz 1");
                 a= teclado.nextInt();
                 System.out.print("Ingrese las columnas para la matriz 1");
                 b= teclado.nextInt();
                 punto1.matrizA = new int[a][b];
                 punto1.completarMatriz(punto1.matrizA, teclado);
                 System.out.print("Ingrese el numero escalar: ");
                 int escalar = teclado.nextInt();
                 punto1.Escalar(escalar);
                 System.out.println("El producto del escalar por la matriz es: ");
                 for (int i = 0; i < punto1.matrizR.length; i++) {
                     for (int j = 0; j < punto1.matrizR[0].length; j++) {
                         System.out.print(punto1.matrizR[i][j] + " ");
                     }
                     System.out.println();
                 }
            }
             case 4 -> {
                 System.out.print("Ingrese el numero de filas de la matriz: ");
                 a= teclado.nextInt();
                 System.out.print("Ingrese el numero de columnas de la matriz: ");
                 b= teclado.nextInt();
                 punto1.matrizA = new int[a][b];
                 punto1.completarMatriz(punto1.matrizA, teclado);
                 punto1.trans();
                 System.out.println("La transpuesta de la matriz es: ");
                 for (int i = 0; i < punto1.matrizR.length; i++) {
                     for (int j = 0; j < punto1.matrizR[0].length; j++) {
                         System.out.print(punto1.matrizR[i][j] + " ");
                     }
                     System.out.println();
                 }
            }
             case 5 -> s=5;
         }
    } while (s!=5);
    } 
}

package guiapkg22;
import java.util.Scanner;
public class Matrices {

    public int [][] matrizA;
    public int [][] matrizB;
    public int [][] matrizR;
    public static void main(String[] args) {

    }
    public void completarMatriz(int[][] matrizA, Scanner scanner) {
        for (int i = 0; i < matrizA.length; i++) {
            for (int j = 0; j < matrizA[0].length; j++) {
                System.out.println("Ingrese el valor para la fila " + (i+1) + " y columna " + (j+1) + ": ");
                matrizA[i][j] = scanner.nextInt();
            }
        }
    }

    
    public void suma(){
        if (matrizA.length != matrizB.length || matrizA[0].length != matrizB[0].length) {
            System.out.println("Las matrices deben tener las mismas dimensiones para poder sumarlas.");
            return;
        }
        int filas = matrizA.length;
        int columnas = matrizA[0].length;
        matrizR = new int[filas][columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matrizR[i][j] = matrizA[i][j] + matrizB[i][j];
            }
        }
    }
    
   public void producto(){
        if (matrizA[0].length != matrizB.length) {
            System.out.println("El número de columnas de la primera matriz debe ser igual al número de filas de la segunda matriz para poder multiplicarlas.");
            return;
        }
        int filas = matrizA.length;
        int columnas = matrizB[0].length;
        matrizR = new int[filas][columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                for (int k = 0; k < matrizA[0].length; k++) {
                    matrizR[i][j] += matrizA[i][k] * matrizB[k][j];
                }
            }
        }
   }
    public void Escalar(int escalar){
        int filas = matrizA.length;
        int columnas = matrizA[0].length;
        matrizR = new int[filas][columnas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matrizR[i][j] = escalar * matrizA[i][j];
            }
        }
    }
    public void trans(){
        int filas = matrizA.length;
        int columnas = matrizB[0].length;
        matrizR = new int[columnas][filas];
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matrizR[j][i] = matrizA[i][j];
            }
        }
    }
}




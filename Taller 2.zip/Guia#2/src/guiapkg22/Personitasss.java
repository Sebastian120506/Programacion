package guiapkg22;
import java.util.Scanner;

public class Personitasss {
    public int cc;
    public String name;
    public float estatura;
    public float años;

    public Personitasss(int cedula, String name, float estatura, float años) {
        this.cc = cedula;
        this.name = name;
        this.estatura = estatura;
        this.años = años;
    }
    public static void mergeSort(Personitasss[] arr, int s, int q, String criterio) {
        if (s < q){
            int m = (s + q) / 2;
            mergeSort(arr, s, m, criterio);
            mergeSort(arr, m + 1, q, criterio);
            merge(arr, s, m, q, criterio);
        }
    }

    public static void bubbleSort(Personitasss[] arr, String criterio) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (criterio.equals("estatura")) {
                    if (arr[j].estatura > arr[j + 1].estatura) {
                        Personitasss temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                } else {
                    if (arr[j].años > arr[j + 1].años) {
                        Personitasss temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }
        }
    }

    private static void merge(Personitasss[] arr, int s, int w, int r, String criterio) {
        int n1 = w - s + 1;
        int n2 = r - w;

        Personitasss[] S = new Personitasss[n1];
        Personitasss[] R = new Personitasss[n2];

        for (int i = 0; i < n1; ++i)
            S[i] = arr[s + i];
        for (int j = 0; j < n2; ++j)
            R[j] = arr[w + 1 + j];

        int i = 0, j = 0;

        int k = s;
        while (i < n1 && j < n2) {
            if (criterio.equals("estatura")) {
                if (S[i].estatura <= R[j].estatura) {
                    arr[k] = S[i];
                    i++;
                } else {
                    arr[k] = R[j];
                    j++;
                }
            } else { 
                if (S[i].años <= R[j].años) {
                    arr[k] = S[i];
                    i++;
                } else {
                    arr[k] = R[j];
                    j++;
                }
            }
            k++;
        }

        while (i < n1) {
            arr[k] = S[i];
            i++;
            k++;
        }

        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }
        public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el numero de personas:");
        float numPersonas = scanner.nextFloat();
        scanner.nextLine();

        Personitasss[] personas = new Personitasss[(int)numPersonas];

        for (int i = 0; i < numPersonas; i++) {
            System.out.println("Ingrese la cedula de la persona " + (i+1) + ":");
            int cedula = scanner.nextInt();
            scanner.nextLine();

            System.out.println("Ingrese el nombre de la persona " + (i+1) + ":");
            String name = scanner.nextLine();

            System.out.println("Ingrese la estatura de la persona " + (i+1) + ":");
            float estatura = scanner.nextFloat();
            scanner.nextLine(); 

            System.out.println("Ingrese la edad de la persona " + (i+1) + ":");
            float años = scanner.nextInt();
            scanner.nextLine(); 

            personas[i] = new Personitasss(cedula, name, estatura, años);
        }

        System.out.println("¿Como desea ordenar las personas? (1: Estatura, 2: Edad)");
        int opcionOrdenamiento = scanner.nextInt();

        System.out.println("¿Que algoritmo de ordenamiento desea utilizar? (1: MergeSort, 2: Bubble Sort)");
        int Opal = scanner.nextInt();

        if (opcionOrdenamiento == 1) {
            if (Opal == 1) {
                mergeSort(personas, 0, personas.length - 1, "estatura");
            } else {
                bubbleSort(personas, "estatura");
            }
        } else {
            if (Opal == 1) {
                mergeSort(personas, 0, personas.length - 1, "edad");
            } else {
                bubbleSort(personas, "edad");
            }
        }

        System.out.println("Personas ordenadas:");

        for (Personitasss persona : personas) {
            System.out.println(persona.name + " - Cedula: " + persona.cc +
                    ", Estatura: " + persona.estatura + ", Edad: " + persona.años);
        }
    }

}  
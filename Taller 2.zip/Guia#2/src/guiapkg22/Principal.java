package guiapkg22;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args){
        Scanner teclado = new Scanner(System.in);
        int sel;
    do {
      System.out.println("Bienvenido al menu de inicio");
      System.out.println("Seleccione una opcion:");
      System.out.println("1. Calculadora de Matricez");
      System.out.println("2. Tabla de ordenamiento");
      System.out.println("3. Interfaz");
      System.out.println("4. Salir");  
      sel=teclado.nextInt();
      
      switch (sel){
          case 1 -> {
                Calculadora punto1 = new   Calculadora();
               punto1.ejecutar();
          }
        
          case 2 -> {
               Arreglos punto2 = new Arreglos();
               punto2.ejecutar();
          }
          case 3 -> {
              Interfazze int1=new Interfazze();
              int1.setVisible(true);
          }
          
         case 4 -> sel=4;
         
      }
        
    } while (sel != 4);

}
}
             
     

 
   
    


package taller6666;

import javax.swing.JLabel;
import javax.swing.JTextArea;

public class Taller6666 {
    private JLabel mov;
    private Carrera carro;
    private JTextArea txt;

    public Taller6666(JLabel mov, Carrera carro, JTextArea txt) {
        this.mov = mov;
        this.carro = carro;
        this.txt = txt;
    }

    Thread hilo1 = new Thread() {
        @Override
        public void run() {
            int carro_1 = 0;
            long ti = System.currentTimeMillis();

            while (true) {
                try {

                    sleep((int) (Math.random() * 1000));
                    carro_1 = carro.getCarro1().getLocation().x;

                    if (carro_1 < carro.getmeta().getLocation().x - 100) {
                        mov.setLocation(mov.getLocation().x + 10, mov.getLocation().y);
                        carro.repaint();

                    } else {
                        long tf = System.currentTimeMillis();
                        long td = (tf - ti) / 1000;
                        txt.append("Carro 1------Tiempo de llegada: "+td+"s\n");
                        break;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    };
    Thread hilo2 = new Thread() {
        @Override
        public void run() {
            int carro_2 = 0;
            long ti = System.currentTimeMillis();
            
            while (true) {
                try {
                    sleep((int) (Math.random() * 1000));
                    carro_2 = carro.getCarro2().getLocation().x;

                    if (carro_2 < carro.getmeta().getLocation().x - 100) {
                        mov.setLocation(mov.getLocation().x + 10, mov.getLocation().y);
                        carro.repaint();

                    } else {
                        long tf = System.currentTimeMillis();
                        long td = (tf - ti) / 1000;
                        txt.append("Carro 2------Tiempo de llegada: "+td+"s\n");
                        break;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    };
    Thread hilo3 = new Thread() {
        @Override
        public void run() {
            int carro_3 = 0;
            long ti = System.currentTimeMillis();
            while (true) {
                try {
                    sleep((int) (Math.random() * 1000));
                    carro_3 = carro.getCarro3().getLocation().x;

                    if (carro_3 < carro.getmeta().getLocation().x - 100) {
                        mov.setLocation(mov.getLocation().x + 10, mov.getLocation().y);
                        carro.repaint();

                    } else {
                        long tf = System.currentTimeMillis();
                        long td = (tf - ti) / 1000;
                        txt.append("Carro 3------Tiempo de llegada: "+td+"s\n");;
                        break;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    };
    Thread hilo4 = new Thread() {
        @Override
        public void run() {
            int carro_4 = 0;
            long ti = System.currentTimeMillis();
            while (true) {
                try {
                    sleep((int) (Math.random() * 1000));
                    carro_4 = carro.getCarro4().getLocation().x;

                    if (carro_4 < carro.getmeta().getLocation().x - 100) {
                        mov.setLocation(mov.getLocation().x + 10, mov.getLocation().y);
                        carro.repaint();

                    } else {
                        long tf = System.currentTimeMillis();
                        long td = (tf - ti) / 1000;
                        txt.append("Carro 4------Tiempo de llegada: "+td+"s\n");
                        break;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    };
    Thread hilo5 = new Thread() {
        @Override
        public void run() {
            int carro_5 = 0;
            long ti = System.currentTimeMillis();
            while (true) {
                try {
                    sleep((int) (Math.random() * 1000));
                    carro_5 = carro.getCarro5().getLocation().x;

                    if (carro_5 < carro.getmeta().getLocation().x - 100) {
                        mov.setLocation(mov.getLocation().x + 10, mov.getLocation().y);
                        carro.repaint();

                    } else {
                        long tf = System.currentTimeMillis();
                        long td = (tf - ti) / 1000;
                        txt.append("Carro 5------Tiempo de llegada: "+td+"s\n");
                        break;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    };
    Thread hilo6 = new Thread() {
        @Override
        public void run() {
            int carro_6 = 0;
            long ti = System.currentTimeMillis();
            while (true) {
                try {
                    sleep((int) (Math.random() * 1000));
                    carro_6 = carro.getCarro6().getLocation().x;

                    if (carro_6 < carro.getmeta().getLocation().x - 100) {
                        mov.setLocation(mov.getLocation().x + 10, mov.getLocation().y);
                        carro.repaint();

                    } else {
                        long tf = System.currentTimeMillis();
                        long td = (tf - ti) / 1000;
                        txt.append("Carro 6------Tiempo de llegada: "+td+"s\n");
                        break;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    };
    Thread hilo7 = new Thread() {
        @Override
        public void run() {
            int carro_7 = 0;
            long ti = System.currentTimeMillis();
            while (true) {
                try {
                    sleep((int) (Math.random() * 1000));
                    carro_7 = carro.getCarro7().getLocation().x;

                    if (carro_7 < carro.getmeta().getLocation().x - 100) {
                        mov.setLocation(mov.getLocation().x + 10, mov.getLocation().y);
                        carro.repaint();

                    } else {
                        long tf = System.currentTimeMillis();
                        long td = (tf - ti) / 1000;
                        txt.append("Carro 7------Tiempo de llegada: "+td+"s\n");
                        break;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    };
    Thread hilo8 = new Thread() {
        @Override
        public void run() {
            int carro_8 = 0;
            long ti = System.currentTimeMillis();
            while (true) {
                try {
                    sleep((int) (Math.random() * 1000));
                    carro_8 = carro.getCarro8().getLocation().x;

                    if (carro_8 < carro.getmeta().getLocation().x - 100) {
                        mov.setLocation(mov.getLocation().x + 10, mov.getLocation().y);
                        carro.repaint();

                    } else {
                        long tf = System.currentTimeMillis();
                        long td = (tf - ti) / 1000;
                        txt.append("Carro 8------Tiempo de llegada: "+td+"s\n");
                        break;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    };
    Thread hilo9 = new Thread() {
        @Override
        public void run() {
            int carro_9 = 0;
            long ti = System.currentTimeMillis();
            while (true) {
                try {
                    sleep((int) (Math.random() * 1000));
                    carro_9 = carro.getCarro9().getLocation().x;

                    if (carro_9 < carro.getmeta().getLocation().x - 100) {
                        mov.setLocation(mov.getLocation().x + 10, mov.getLocation().y);
                        carro.repaint();

                    } else {
                        long tf = System.currentTimeMillis();
                        long td = (tf - ti) / 1000;
                        txt.append("Carro 9------Tiempo de llegada: "+td+"s\n");
                        break;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    };
    Thread hilo10 = new Thread() {
        @Override
        public void run() {
            int carro_10 = 0;
            long ti = System.currentTimeMillis();
            while (true) {
                try {
                    sleep((int) (Math.random() * 1000));
                    carro_10 = carro.getCarro10().getLocation().x;

                    if (carro_10 < carro.getmeta().getLocation().x - 100) {
                        mov.setLocation(mov.getLocation().x + 10, mov.getLocation().y);
                        carro.repaint();

                    } else {
                        long tf = System.currentTimeMillis();
                        long td = (tf - ti) / 1000;
                        txt.append("Carro 10------Tiempo de llegada: "+td+"s\n");
                        break;

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        }
    };
}

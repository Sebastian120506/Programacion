package taller.pkg2;

import java.util.Scanner;

public class Taller2 {
    
    public static void main(String[] args) {
      int menu;
      menu=0;
      
        Scanner ingreso = new Scanner(System.in);
       
        System.out.print("Ingrese el numero de filas de la matriz A: ");
        int filasA = ingreso.nextInt();

        System.out.print("Ingrese el numero de columnas de la matriz A: ");
        int columnasA = ingreso.nextInt();

        int[][] matrizA = new int[filasA][columnasA];

        System.out.println("Ingrese los elementos de la matriz A:");

        for (int i = 0; i < filasA; i++) {
            for (int j = 0; j < columnasA; j++)
            {
                System.out.print("Elemento en la posicion [" + i + "][" + j + "]: ");
                matrizA[i][j] = ingreso.nextInt();
            }
        }


        System.out.println("La matriz ingresada es:");
        for (int i = 0; i < filasA; i++) {
            for (int j = 0; j < columnasA; j++) {
                System.out.print(matrizA[i][j] + " ");
            }
            System.out.println();
        }
        
        System.out.print("Ingrese el numero de filas de la matriz B: ");
        int filasB = ingreso.nextInt();

        System.out.print("Ingrese el numero de columnas de la matriz B: ");
        int columnasB = ingreso.nextInt();

        int[][] matrizB = new int[filasB][columnasB];

        System.out.println("Ingrese los elementos de la matriz B:");

        for (int i = 0; i < filasB; i++) {
            for (int j = 0; j < columnasB; j++)
            {
                System.out.print("Elemento en la posicion [" + i + "][" + j + "]: ");
                matrizB[i][j] = ingreso.nextInt();
            }
        }


        System.out.println("La matriz B ingresada es:");
        for (int i = 0; i < filasB; i++) {
            for (int j = 0; j < columnasB; j++) {
                System.out.print(matrizB[i][j] + " ");
            }
            System.out.println();
        }
        
/**
      do{
        System.out.println("Bienvenido a la Calculadora Matricial");
        System.out.print("Seleccione la operacion que desee realizar");
        System.out.print("1. Suma de matrices");
        System.out.print("2. Producto de matrices ");
        System.out.print("3. Producto de una matriz por un escalar ");
        System.out.print("4. Traspuesta de una matriz ");
        System.out.print("5. CERRAR ");
        menu = ingreso.nextInt();
        System.out.println("Ingrese el numero 1");
        float a = ingreso.nextFloat();
        System.out.println("Ingrese el numero 2");
        float b = ingreso.nextFloat();
        Scanner scanner = new Scanner(System.in);
        cal.num1 = a;
        cal.num2 = b;
        
        switch (menu){
            case 1:
                System.out.println("Usted a seleccionado la operacion 1. Suma de matrices");
                System.out.println("Ingrese el numero 2");
                cal.suma();
                System.out.println("El resultado de la suma es: "+cal.resultado);
                break;
            case 2:
                System.out.println("Usted a seleccionado la operacion 2. Producto de matrices");
                cal.resta();
                System.out.println("El resultado de la multiplicacion es: "+cal.resultado);
                break;
            case 3: 
                System.out.println("Usted a seleccionado la operacion 3. Producto de mateiz por escalar");
                cal.multi();
                System.out.println("El resultado de la multiplicacion es: "+cal.resultado);
                break;
            case 4:
                System.out.println("Usted a seleccionado la operacion 4. Traspuesta de una matriz");
                cal.divi();
                if(b == 0){
                } else {
                  System.out.println("El resultado de la division es: "+cal.resultado);
                }
                 break;   
        } while(menu!=5)
                 


**/

            }
      }
